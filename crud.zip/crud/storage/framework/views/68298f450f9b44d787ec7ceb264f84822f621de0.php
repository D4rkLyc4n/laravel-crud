<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        body {
            padding: 0px;
            margin: 0px;
            
        }

        /* Sidebar styles */
        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: #f0f0f0;
            float: left;
            background-color: #420E7D;
        }
        
        /* Main content styles */
        .content {
            margin-left: 200px;
        }

        /* Menu bar styles */
        .menu-bar {
            display: none;
            background-color: #420E7D;
            color: white;
            padding: 10px;
        }

        /* Media query for mobile */
        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
            .content {
                margin-left: 0;
            }
            .menu-bar {
                display: block;
            }
        }

        /* CSS Grid container */
        .grid-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 20px;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Custom card styles */
        .card {
            padding: 20px;
            text-align: center;
            color: #fff;
            font-weight: bold;
            font-size: 20px;
            border-radius: 5px;
        }

        /* Random background colors */
        .card-users {
            background-color: #420E7D;
        }

        .card-reach {
            background-color: #420E7D;
        }

        .card-health {
            background-color: #420E7D;
        }

        .card-more {
            background-color: #420E7D;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <!-- Sidebar content here -->
        <h3 style="color:white;">Admin Panel</h3>
        <ul>
            <li><a href="<?php echo e(url('recs/create')); ?>" class="btn btn-info">Create</a></li><br>
            <li><a href="<?php echo e(url('/recs')); ?>" class="btn btn-info">Posts</a></li><br>
            <li><a href="#" class="btn btn-info">Logout</a></li>
        </ul>
    </div>

    <div class="content">
        <div class="menu-bar">
            <!-- Menu bar content here -->
            <h3 style="color:white;">Admin Panel</h3>
        </div>
        <div class="grid-container">
            <div class="card card-users"><a href="<?php echo e(url('/recs')); ?>">Posts</a></div>
            <div class="card card-reach"><a href="<?php echo e(url('recs/create')); ?>">Create</a></div>
            <div class="card card-health"><a href="<?php echo e(url('/recs')); ?>">Edit</a></div>
            <div class="card card-more"><a href="<?php echo e(url('/recs')); ?>">Del</a></div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH /home/darklycan/dev/crud/resources/views/home/index.blade.php ENDPATH**/ ?>